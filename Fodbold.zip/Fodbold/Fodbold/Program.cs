using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static System.Console; // Gør så vi ikke skal skrive Console.osv hele tiden

namespace Fodbold
{
    class Program
    {
        static void Main(string[] args)
        {
            string type;
            string navn;
            string fail;
            string V;
            string date;
            string pladser;

            int antalv;

            decimal pris = 0;
            decimal bpris = 0;
            decimal vpris = 0;
            decimal rabat = 0;
            decimal USD = 625.45M;
            decimal antalb = 0;
            decimal totalbilet = 0;


            pladser = "100";

            System.IO.File.WriteAllText(@"C:\Users\claus\Desktop\Fodbold\fodbold.txt", pladser);

            pladser = System.IO.File.ReadAllText(@"C:\Users\claus\Desktop\Fodbold\fodbold.txt");


            startup(); // starter vores program

            void startup() // Sender besked til de forskellige koder at de skal executes
            {
                rabat = 0; 
                date = DateTime.Now.ToString("dd-MM-yyyy"); 
                Clear();
                layout();
                name();
                billetbørn();
            }

            void genstart() //Bliver brugt hvis der er input fejl
            {
                layout();
                information();
                billetbørn();
            }

            void layout() // laver vores "smukke" layout
            {
                ForegroundColor = ConsoleColor.Red; // rød tekst
                BackgroundColor = ConsoleColor.Yellow; // gul baggrund
                WriteLine("/////////////////////TEC Ballerup stadion/////////////////////");
                Write("/");
                ResetColor();
                Write("        TEC's online billetautomat        ");
                Write(date); // skriver datoen
                Write("        ");
                ForegroundColor = ConsoleColor.Red;
                BackgroundColor = ConsoleColor.Yellow;
                WriteLine("/");
                WriteLine("//////////////////////////////////////////////////////////////");
                ResetColor();
                WriteLine("Antal pladser tilbage {0}", pladser);
            }
            
            // Skaffer personens navn for at gøre det mere personligt
            void name()
            {
                WriteLine("");
                Write("Indtast navn: ");
                
                navn = Console.ReadLine();
                Clear();
                layout();
                information();

            }

            // Skriver en lille information samt velkomstbedsked
            void information()
            {
                WriteLine("");
                WriteLine("Velkommen til TEC's online billetautomat {0}!", navn);
                WriteLine("Her er det muligt at bestille dine biletter til søndagens kamp.");
                WriteLine("Nemt og hurtigt!");
                WriteLine("");
                WriteLine("Følg instrukserne for at gennemføre din bestilling!");
            }

            // Bruges for at finde ud af hvor mange børnebiletter brugeren af programmet vil have
            void billetbørn()
            {
                try // tester om dette virker ellers bliver der sendt et ERROR
                {
                    Console.WriteLine("");
                    Console.WriteLine("[Børnebillet 30 kr.]");
                    Console.Write("Indtast ønskede antal: ");
                    antalb = Convert.ToInt32(Console.ReadLine()); // laver input om til tal, hvis input ikke er et tal kommer den med et ERROR

                    if (antalb > 10) // Sætter maks køb til 10
                    {
                        fail = "Man kan maks købe 10 børnebiletter!"; // valgte at bruge en string til ERROR's bedskeder for at spare plads
                        fejl(); // Sender fejl som er længere nede
                    }
                    else if (antalb < 0) // Så man ikke kan købe -1 billet og få penge
                    {
                        fail = "Man kan ikke købe under 0 biletter!";
                        fejl(); // Sender fejl som er længere nede
                    }
                    else
                    {
                        billetvoksen(); // Sender en videre til billetvoksen
                    }
                }
                catch (Exception) // Hvis man ikke indtaster et tal bliver der vist en fejlbedsked
                {
                    fail = ("Kun tal!");
                    fejl();
                }
            }

            // Næsten den samme som billetbørn
            // Har gjort så hvis man laver input fejl her "gemmer" den dit tidligere svar på billetbørn
            // Så man ikke skal skrive det samme 2 gange.
            void billetvoksen()
            {
                try
                {
                    Console.WriteLine("");
                    Console.WriteLine("[Voksenbillet 65 kr.]");
                    Console.Write("Indtast ønskede antal: ");
                    antalv = Convert.ToInt32(Console.ReadLine());

                    if (antalv > 10)
                    {
                        fail = "Man kan maks købe 10 voksenbiletter!";
                        fejlv(); // Sender en videre til fejl bedsked
                    }
                    else if (antalv < 0)
                    {
                        fail = "Man kan ikke købe under 0 biletter!";
                        fejlv();
                    }
                    else
                    {
                        valuta(); // sender dig videre
                    }
                }
                catch (Exception)
                {
                    fail = ("Kun tal!");
                    fejlv();
                }
            }

            // Til de udlandske besøgende som vil betale i USD
            void valuta()
            {
                try
                {
                    WriteLine("");
                    WriteLine("Du kan betale med USD eller DKK");
                    Write("Indtast USD eller DKK: "); //vælge som man vil betale i DKK eller USD

                    V = Console.ReadLine().ToLower(); // Gør så dit input bliver til variablen V

                    totalbilet = antalb + antalv; // for at regne samlet antal biletter ud.
                    
                    if (V == "usd" | V == "us" | V == "u" | V == "$") // inputs som vi acceptere for USD
                    {
                        V = "$"; // sætter V til $ for synets skyld så der ikke står f.eks. 20 us eller u, hvad man nu skriver ind
                        bpris = (antalb * 30) / (USD / 100); // beregner prisen ud med USD kurs som ligger på 625.45
                        bpris = Math.Round(bpris, 0, MidpointRounding.AwayFromZero);
                        vpris = (antalv * 65) / (USD / 100); // ^^
                        vpris = Math.Round(vpris, 0, MidpointRounding.AwayFromZero);
                        pris = bpris + vpris;                // ^^
                        pris = Math.Round(pris, 0, MidpointRounding.AwayFromZero);
                        
                        

                        bekræft(); // Sender dig videre
                    }
                    else if (V == "dkk" | V == "kr") // inputs som vi acceptere for DKK
                    {
                        V = "Kr."; 
                        bpris = (antalb * 30); // beregner pris
                        bpris = Math.Round(bpris, 0, MidpointRounding.AwayFromZero);
                        vpris = (antalv * 65); // ^^
                        vpris = Math.Round(vpris, 0, MidpointRounding.AwayFromZero);
                        pris = bpris + vpris;  // ^^
                        pris = Math.Round(pris, 0, MidpointRounding.AwayFromZero);
                        bekræft(); // Sender dig videre
                    }
                    else // Hvis man indtaster nogle at de inputs vi ikke acceptere kommer den med en fejl
                    {
                        throw new Exception();
                    }

                }
                catch (Exception) // Hvis der sker et ERROR
                {
                    fail = ("Denne valuta tager vi ikke imod!");
                    fejl();
                }
            }

            // Man kan få lov til at se ens bestilling inden man betaler
            // Det meste er bare normal tekst
            // Der er dog brug af index
            void bekræft()
            {
                WriteLine("");
                WriteLine("Tjek at din bestilling er rigtig:");
                WriteLine("{0} x børnebiletter  . . {1}{2}", antalb, V, bpris);
                WriteLine("{0} x voksenbiletter . . {1}{2}", antalv, V, vpris);
                WriteLine("----------------------------------");
                WriteLine("{0} x Biletter i alt", totalbilet);
                WriteLine("Total . . . . . . . .  {0}{1}", V, pris);
                WriteLine("");
                WriteLine("Tryk på en tast for at forsætte!");
                ReadKey();
                medlemcheck(); // Sender dig videre

            }

            // Man for 10% rabat hvis man er del af klubbens foreningsgruppe
            // Man svare om man er medlem 
            // Hvis man ikke skriver ja eller nej antager jeg at man ikke er medlem ellers kunne man gøre som vi gjorde før hvor -
            // vi kun acceptered nogle inputs.
            void medlemcheck()
            {
                WriteLine("");
                WriteLine("Som medlem af klubbens foreningsgruppe får man 10% på ens køb.");
                WriteLine("Er du medlem af klubbens foreningsgruppe?");
                Write("Ja / Nej: ");

                type = Console.ReadLine().ToLower();

                if (type == "ja") //Hvis man er medlem beregner den rabatten man har fået og den nye pris
                {
                    rabat = pris * 0.10M;
                    rabat = Math.Round(rabat, 0, MidpointRounding.AwayFromZero);
                    pris = pris - rabat;
                }
                kvit(); // Sender dig videre
            }

            //Viser en overskuelig "side" hvor man kan se ens køb er gået igennem og man kan så lov til at lave en ny bestilling ved at trykke på en knap.
            // Det meste er bare normal tekst
            // Der er dog brug af index
            void kvit()
            {
                Clear();
                layout();
                ForegroundColor = ConsoleColor.DarkGreen;
                WriteLine("");
                WriteLine("Køb bekræftet!");
                ResetColor();
                WriteLine("");
                WriteLine("{0} x børnebiletter  . . {1}{2}", antalb, V, bpris);
                WriteLine("{0} x voksenbiletter . . {1}{2}", antalv, V, vpris);
                WriteLine("Rabat  . . . . . . . . {0}{1}", V, rabat);
                WriteLine("----------------------------------");
                WriteLine("{0} x biletter i alt", totalbilet);
                WriteLine("Total . . . . . . . .  {0}{1}", V, pris);
                WriteLine("");
                WriteLine("Du kan nu afslutte eller åbne ny bestilling.");
                Write("Indtast (Afslut / Åben): ");

                type = Console.ReadLine().ToLower();

                if (type == "åben" | type == "ny")
                {
                    startup();
                }
                else
                {
                    WriteLine();
                    WriteLine("Go' kamp!");
                    WriteLine("Tryk på en tast for at lukke vinduet");
                    ReadKey();
                }
            }

            // Den gemmer vores svar på antal børnebiletter, hvis vi laver forkert input på voksenbiletter.
            void bholder()
            {
                Console.WriteLine("");
                Console.WriteLine("[Børnebillet 30 kr.]");
                Console.WriteLine("Indtast ønskede antal: {0}", antalb);
            }

            // Vores ene fejl som genstarter alt untaget ens navn
            void fejl()
            {
                Beep(440, 500);
                ForegroundColor = ConsoleColor.Red;
                WriteLine("");
                WriteLine("{0}", fail);
                WriteLine("(Tjek input)");
                WriteLine("");
                ResetColor();
                WriteLine("Tryk på en tast for at genstarte");
                ReadKey();
                Clear();
                genstart();
            }

            // Vores sidste fejl som sender en tilbage til antal voksene hvis man har skrevet forkert
            void fejlv()
            {
                Beep(440, 500);
                ForegroundColor = ConsoleColor.Red;
                WriteLine("");
                WriteLine("{0}", fail);
                WriteLine("(Tjek input)");
                WriteLine("");
                ResetColor();
                WriteLine("Tryk på en tast for at genstarte");
                ReadKey();
                Clear();
                layout();
                information();
                bholder();
                billetvoksen();
            }
        }
    }
}
